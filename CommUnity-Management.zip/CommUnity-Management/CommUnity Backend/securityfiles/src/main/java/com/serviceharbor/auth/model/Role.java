package com.serviceharbor.auth.model;

public enum Role {
    RESIDENT,
    ADMIN
}