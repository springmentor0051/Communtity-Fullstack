package com.capstone.SocietyManagementService;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SocietyManagementServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
