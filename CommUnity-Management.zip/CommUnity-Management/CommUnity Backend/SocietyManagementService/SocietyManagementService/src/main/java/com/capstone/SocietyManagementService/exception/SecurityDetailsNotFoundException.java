package com.capstone.SocietyManagementService.exception;

public class SecurityDetailsNotFoundException extends RuntimeException {
    public SecurityDetailsNotFoundException(String message) {
        super(message);
    }
}
