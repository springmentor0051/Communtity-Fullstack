package com.capstone.SocietyManagementService.exception;

public class SocietyNotFoundException extends RuntimeException {
    public SocietyNotFoundException(String message) {
        super(message);
    }
}