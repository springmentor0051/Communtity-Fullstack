package com.capstone.SocietyManagementService.exception;

public class ResidentNotFoundException extends RuntimeException {
    public ResidentNotFoundException(String message) {
        super(message);
    }
}
