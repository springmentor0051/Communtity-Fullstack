package com.capstone.SocietyManagementService.exception;

public class DuplicateFlatException extends RuntimeException {
    public DuplicateFlatException(String message) {
        super(message);
    }
}
