package com.capstone.SocietyManagementService.model;

public enum Role {
    ADMIN,
    RESIDENT
}