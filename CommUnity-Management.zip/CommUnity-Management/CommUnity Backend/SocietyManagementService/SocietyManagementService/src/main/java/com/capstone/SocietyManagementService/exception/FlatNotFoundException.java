package com.capstone.SocietyManagementService.exception;

public class FlatNotFoundException extends RuntimeException {
    public FlatNotFoundException(String message) {
        super(message);
    }
}