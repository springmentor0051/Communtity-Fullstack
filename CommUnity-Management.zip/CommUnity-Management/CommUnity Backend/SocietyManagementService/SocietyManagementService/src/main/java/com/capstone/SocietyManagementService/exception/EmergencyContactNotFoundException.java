package com.capstone.SocietyManagementService.exception;

public class EmergencyContactNotFoundException extends RuntimeException {
    public EmergencyContactNotFoundException(String message) {
        super(message);
    }
}
