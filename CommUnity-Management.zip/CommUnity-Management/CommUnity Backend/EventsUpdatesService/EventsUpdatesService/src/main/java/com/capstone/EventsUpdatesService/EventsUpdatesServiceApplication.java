package com.capstone.EventsUpdatesService;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EventsUpdatesServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(EventsUpdatesServiceApplication.class, args);
	}
}