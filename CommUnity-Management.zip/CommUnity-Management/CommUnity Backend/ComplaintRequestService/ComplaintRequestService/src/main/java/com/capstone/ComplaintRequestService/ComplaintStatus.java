package com.capstone.ComplaintRequestService;

public enum ComplaintStatus {
    OPEN, CLOSED;
}
