package com.capstone.PaymentService.dto;

public enum Role {
    RESIDENT,
    ADMIN
}